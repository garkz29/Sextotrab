/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex2;

import java.util.Scanner;
public class Ex2_2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double acrescimo;
        double valor;
        double valorf;
        
        System.out.println("Digite o valor do produto: ");
        valor = input.nextDouble();
        
        System.out.println("Digite a taxa de acrescimo (não é necessario colocar a porcentagem %)" );
        acrescimo = input.nextDouble();
        
        valorf = valor * (1+(acrescimo / 100));
        
        System.out.println(valorf);
    }
    
}
