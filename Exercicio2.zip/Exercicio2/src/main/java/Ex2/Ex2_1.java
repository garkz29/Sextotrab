/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex2;

import java.util.Scanner;

public class Ex2_1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double raio;
        double resultado;
        
        System.out.println("Digite o raio do circulo: ");
        raio = input.nextDouble();
        
        resultado = (raio * raio)* 3.14;
        
        System.err.println("A area desse circulo é: " + resultado);
    }
    
}
